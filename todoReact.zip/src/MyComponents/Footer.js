import React from 'react'


export const Footer = () => { 
    return (
        <footer className="text-center bg-dark text-lg-start text-light mt-5 position-sticky">
            <div className="text-center p-3">
            Copyright &copy; Jangids.com
            </div>
        </footer>
    )
}
